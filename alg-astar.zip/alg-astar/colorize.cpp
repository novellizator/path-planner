#include <stack>

#include "globals.h"
#include "Entry.h"
#include "colorize.h"

using namespace std;


//int main()
//{
//	
//	width = 4;
//	height = 3;
//
//  //  for(int l= 0; l < 16; ++l)
//		//cout << "lokace" << getLoc(l).x <<" "<< getLoc(l).y << endl;
//
//    // vector<bool> map = push("011100110111"); // ok
//    // vector<bool> map = push("111010101111"); // ok
//    // vector<bool> map = push("110111111111");
//	vector<bool> map = push("110110111011");
//    findRectangle(map);
//    system("pause");
//    return 0;
//}
//-------------------------------------------------



